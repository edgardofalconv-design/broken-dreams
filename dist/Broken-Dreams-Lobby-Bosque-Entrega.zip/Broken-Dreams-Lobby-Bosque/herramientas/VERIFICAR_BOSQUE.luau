-- Ejecutar en Command Bar después de abrir el proyecto, preferiblemente en Play / Server.
local lobby=assert(workspace:FindFirstChild("BrokenDreamsLobby"),"Falta el lobby")
local forest=assert(lobby:FindFirstChild("ForestExterior"),"Falta el bosque")
local origin=lobby:GetAttribute("Origin")
assert(not lobby.TentStructure.Collision:FindFirstChild("EntrySafetyBoundary"),"La salida de la carpa sigue bloqueada")
local state=game.ReplicatedStorage:FindFirstChild("BrokenDreamsLobbyState")
assert(state:GetAttribute("LobbyBoundsMax").X>=90,"El área del HUD no incluye el bosque")
assert(game.Lighting:FindFirstChild("BD_ForestAtmosphere"),"Falta la atmósfera")
local ray=RaycastParams.new();ray.FilterType=Enum.RaycastFilterType.Include;ray.FilterDescendantsInstances={lobby};ray.RespectCanCollide=true
local overlap=OverlapParams.new();overlap.FilterType=Enum.RaycastFilterType.Include;overlap.FilterDescendantsInstances={lobby};overlap.RespectCanCollide=true
local probes={}
for i=0,119 do local t=i*math.pi*2/120;table.insert(probes,Vector3.new(55*math.cos(t),0,47*math.sin(t))) end
for z=27,63,2 do table.insert(probes,Vector3.new(0,0,z)) end
for _,p in {Vector3.new(-61,0,8),Vector3.new(61,0,7),Vector3.new(0,0,60)} do table.insert(probes,p) end
local failures={}
for _,p in probes do
 local hit=workspace:Raycast(origin+p+Vector3.new(0,6,0),Vector3.new(0,-9,0),ray)
 if not hit then table.insert(failures,"Falta suelo: "..tostring(p))
 elseif math.abs(hit.Position.Y-(origin.Y+.4))>.5 then table.insert(failures,"Suelo inesperado: "..tostring(p))
 else
  local blocked=workspace:GetPartBoundsInBox(CFrame.new(hit.Position+Vector3.new(0,2.6,0)),Vector3.new(2.5,4.7,2.5),overlap)
  if #blocked>0 then table.insert(failures,"Posible obstáculo: "..tostring(p).." / "..blocked[1]:GetFullName()) end
 end
end
local parts,lights=0,0
for _,o in forest:GetDescendants() do
 if o:IsA("BasePart") then parts+=1;assert(o.Anchored,"Objeto suelto: "..o:GetFullName()) end
 if o:IsA("PointLight") then lights+=1 end
end
print("BROKEN DREAMS bosque:",#probes,"posiciones;",parts,"piezas exteriores;",lights,"luces exteriores;",#failures,"avisos")
for _,message in failures do warn(message) end
assert(#failures==0,"Revisa los avisos anteriores")
print("Comprobación estructural completa. Prueba caminar, saltar, la cámara, la niebla, el HUD exterior y multijugador.")
