from pathlib import Path
import json,math,random
import numpy as np

# Reuse the exact primitive construction helpers of the existing lobby.
source=Path('work/lobby/generate.py').read_text().split('# Floor and collision shell:')[0]
scope={};exec(source,scope)
part,ball,beam,path,ring,triangle,cloth,text,lamp,crate,barrel,yaw=[scope[k] for k in ['part','ball','beam','path','ring','triangle','cloth','text','lamp','crate','barrel','yaw']]
nodes,texts,lights,C=[scope[k] for k in ['nodes','texts','lights','C']]
random.seed(7193)
C.update(grass=[52,82,64],grasslight=[75,112,73],moss=[66,100,68],bark=[72,55,49],barklight=[99,73,52],earth=[102,76,50],stone=[79,91,94],leaf=[47,83,75],leaflight=[64,103,80],leafblue=[44,77,85],dead=[91,77,67],mint=[138,218,174])
I=np.eye(3);Ry=np.array([[0,-1,0],[1,0,0],[0,0,1]])

def rock(group,pos,size,moss=True,hit=True):
 x,y,z=pos;sx,sy,sz=size
 i=part(group,'WeatheredStone',(x,y+sy*.45,z),size,'stone','Slate',yaw(random.uniform(-.7,.7)),shape='Ball',collide=hit)
 if moss:part(group,'MossCap',(x,y+sy*.82,z),(sx*.84,sy*.21,sz*.8),'moss','Grass',shape='Ball')
 return i

def ribbon(group,name,a,b,width,col,mat='Ground'):
 a,b=np.array(a,float),np.array(b,float);z=b-a;z[1]=0;length=np.linalg.norm(z);z/=length;y=np.array([0,1,0]);x=np.cross(y,z)
 return part(group,name,(a+b)/2,(width,.045,length+.25),col,mat,np.column_stack((x,y,z)))

def tree(x,z,scale=1,dead=False,boundary=False):
 g='Trees/'+('Boundary' if boundary else 'Inner')
 height=random.uniform(19,27)*scale;lean=random.uniform(-2,2);bend=random.uniform(-2,2)
 centers=[(x,.45,z),(x+lean*.3,height*.3,z+bend*.4),(x-lean*.5,height*.65,z+bend),(x+lean,height,z+bend*.4)]
 for j in range(3):
  idx=beam(g,'TwistedTrunk',centers[j],centers[j+1],(2.8-j*.5)*scale,'dead' if dead else 'bark')
  nodes[idx]['hit']=True
 for a in [random.random()*math.tau+j*math.tau/3 for j in range(3)]:
  p=(x+math.cos(a)*4*scale,.5,z+math.sin(a)*4*scale)
  beam(g,'SpreadingRoot',(x,1.7*scale,z),p,.65*scale,'bark')
 for side in [-1,1]:
  start=centers[2];end=(x+side*5.0*scale,height*.92,z+(2 if side==1 else -2)*scale)
  beam(g,'CrookedBranch',start,end,.85*scale,'bark')
 if not dead:
  for dx,dy,dz,s in [(-4,-2,0,1),(3,-1,1,1),(0,2,-1,1.15)]:
   col=random.choice(['leaf','leaflight','leafblue'])
   ball(g,'StylizedCanopy',(x+dx*scale,height+dy*scale,z+dz*scale),(12*scale*s,7*scale*s,11*scale*s),col,'Grass')
  if random.random()<.3:
   ball(g,'VioletLichen',(x+1,height*.4,z+1),(1,.35,1),'purple','Grass')

def grass(x,z):
 for a in [random.random()*math.pi,random.random()*math.pi]:
  R=yaw(a);p=np.array([x,.48,z]);w=random.uniform(.25,.5);h=random.uniform(.6,1.1)
  triangle('Undergrowth/Grass','GrassBlade',p+R@np.array([-w,0,0]),p+R@np.array([w,0,0]),p+R@np.array([.15,h,.06]),'grasslight')

def clear_point(x,z):
 # Keep the tent perimeter, entry avenue and the entire loop free of vegetation.
 if abs(x)<39 and abs(z)<33:return False
 if abs(x)<9 and 28<z<73:return False
 t=math.atan2(z/47,x/55);px,pz=55*math.cos(t),47*math.sin(t)
 if math.hypot(x-px,z-pz)<5:return False
 for cx,cz,r in [(-61,8,7),(61,7,7),(0,60,9)]:
  if math.hypot(x-cx,z-cz)<r:return False
 return True

# Single stable collision surface aligned to the existing tent floor.
part('Ground','ForestFoundation',(0,-.6,0),(2,178,166),'grass','Grass',Ry,'Cylinder',True)
part('Ground','LowerEarthBank',(0,-2,0),(2,180,168),'earth','Ground',Ry,'Cylinder',False)

# Continuous, low dirt paths, including the approach through the old entry boundary.
loop=[]
for t in np.linspace(0,math.tau,73):loop.append((55*math.cos(t),.46,47*math.sin(t)))
for a,b in zip(loop,loop[1:]):ribbon('Paths','EncirclingDirtPath',a,b,7.5,'earth')
for a,b in [((0,.46,32),(0,.46,61)),((-55,.46,8),(-62,.46,8)),((55,.46,7),(62,.46,7))]:ribbon('Paths','ClearingConnector',a,b,8,'earth')
for x,z,diam in [(0,60,18),(-61,8,15),(61,7,15)]:
 part('Paths','GatheringClearing',(x,.46,z),(.05,diam,diam),'earth','Ground',Ry,'Cylinder')
for i in range(70):
 a=i*math.tau/70;r=random.choice([-4.4,4.4]);x=(55+r)*math.cos(a);z=(47+r)*math.sin(a)
 part('Paths','PathEdgePebble',(x,.6,z),(.6,.3,.9),'stone','Slate',yaw(a),'Ball')

# Visible continuous boundary: woody escarpment and moss-covered boulders below dense trees.
boundary=[]
for i in range(56):
 a=i*math.tau/56;b=(i+1)*math.tau/56
 A=np.array([83*math.cos(a),0,77*math.sin(a)]);B=np.array([83*math.cos(b),0,77*math.sin(b)])
 mid=(A+B)/2;tangent=B-A;tangent/=np.linalg.norm(tangent);y=np.array([0,1,0]);normal=np.cross(y,tangent)
 h=random.uniform(13,18);length=np.linalg.norm(B-A)+2
 part('NaturalBoundary','RootAndRockBank',mid+[0,h/2,0],(7,h,length),'bark','Slate',np.column_stack((normal,y,tangent)),collide=True)
 rock('NaturalBoundary/MossyRocks',mid+[0,0,0],(8,h*.8,8),True,False)
 ball('NaturalBoundary','DenseBramble',mid+[0,h*.85,0],(12,7,10),'leaf','Grass')
 boundary.append((A.tolist(),B.tolist()))
for i in range(52):
 a=(i+.25)*math.tau/52;x=80*math.cos(a);z=74*math.sin(a)
 tree(x,z,random.uniform(.85,1.3),dead=(i%11==0),boundary=True)

# Irregular trees on both sides of the loop, with passable glades.
tree_locations=[]
for _ in range(300):
 x=random.uniform(-72,72);z=random.uniform(-67,67)
 if (x/76)**2+(z/70)**2>1 or not clear_point(x,z):continue
 if any(math.hypot(x-a,z-b)<12 for a,b in tree_locations):continue
 tree_locations.append((x,z));tree(x,z,random.uniform(.65,.95),dead=len(tree_locations)%7==0)
 if len(tree_locations)>=23:break

# Walkable center is untouched: small foliage is non-colliding and off paths.
for _ in range(270):
 x=random.uniform(-76,76);z=random.uniform(-70,70)
 if clear_point(x,z) and (x/78)**2+(z/72)**2<1:grass(x,z)
for x,z in [(-42,-20),(42,-20),(-63,-15),(65,25),(-36,48),(35,53),(-23,-55),(22,-59)]:
 rock('Rocks',(x,.4,z),(random.uniform(3,5),random.uniform(2,3.2),random.uniform(3,5)))

# Fallen trunks at the clearings, with visible cut rings and no obstruction across the path.
for x,z,a in [(-64,16,.3),(65,16,-.3),(-17,58,.9),(21,-59,-.5)]:
 R=yaw(a);A=np.array([x,1.4,z])+R@np.array([-4,0,0]);B=np.array([x,1.4,z])+R@np.array([4,0,0])
 idx=beam('FallenLogs','FallenTrunk',A,B,2.1,'bark');nodes[idx]['hit']=True
 # Cylinder cut ends: native cylinder axis X, with grain concentric cylinders.
 for sign in [-1,1]:
  p=np.array([x,1.4,z])+R@np.array([sign*4.05,0,0])
  part('FallenLogs','CutEnd',p,(.08,1.9,1.9),'barklight','Wood',R,'Cylinder')
  part('FallenLogs','TreeRing',p+R@np.array([sign*.05,0,0]),(.04,1.2,1.2),'earth','Wood',R,'Cylinder')
  part('FallenLogs','TreeHeart',p+R@np.array([sign*.08,0,0]),(.04,.7,.7),'barklight','Wood',R,'Cylinder')

# Entry: broad wooden approach, open timber arch, faded canopy, pendants and lamp posts.
part('Entrance','EntryExtension',(0,.22,37),(14,.4,6),'wood','Wood',collide=True)
for i in range(7):part('Entrance','EntryPlank',(-6+i*2,.45,37),(1.95,.06,6),'plank','Wood')
for x in [-8.5,8.5]:
 part('Entrance','CarvedGatePost',(x,5.9,38),(.8,11,.8),'bark','Wood',collide=True)
 for y in [1,9.8,11.2]:part('Entrance','PostBands',(x,y,38),(1,.2,1),'gold','Metal')
 ball('Entrance','PostFinial',(x,11.8,38),.8,'gold')
arc=[(8.5*math.cos(t),11.3+4*math.sin(t),38) for t in np.linspace(0,math.pi,17)]
path('Entrance','CrookedWoodenArch',arc,.65,'bark')
path('Entrance','FadedGoldArch',[(x,y+.2,z+.25) for x,y,z in arc],.12,'gold','Metal')
sign=part('Entrance','EntranceTitle',(0,12,38.25),(8,2.5,.2),'purple','Wood',yaw(math.pi))
text(sign,'BROKEN DREAMS',kind='title')
cloth('Entrance','WeatheredAwning',[[[-7,14,29],[0,15,29],[7,14,29]],[[-7,12.5,33.5],[0,13.5,33.5],[7,12.5,33.5]],[[-7,11.2,38],[0,12.2,38],[7,11.2,38]]],'red')
for i in range(7):
 x=-6+i*2
 triangle('Entrance','FadedPennant',(x-.5,11.8,39),(x+.5,11.8,39),(x,10.6,39),['purple','cream','red'][i%3])
for x in [-11,11]:
 part('Entrance','PathLampPost',(x,3.5,40),(.45,6.2,.45),'bark','Wood',collide=True)
 lamp('Lanterns',(x,7.0,40),1,True)
for x,z in [(-13,34),(-14,37),(13,34),(15,36)]:crate((x,.4,z),2.3)
barrel((-16,.4,34));barrel((16,.4,34))

# Old signposts; only guidance, no play buttons or teleport prompts.
for x,z,heading,sub,a in [(17,39,'LA CARPA','REFUGIO',-.2),(-40,23,'VUELVE A LA LUZ','SENDERO DEL LOBBY',.45),(43,-15,'VIEJO SENDERO','BOSQUE EN SILENCIO',-.5)]:
 part('Signs','AgedPost',(x,2.5,z),(.35,4.2,.35),'bark','Wood',yaw(a),collide=True)
 f=part('Signs','OldSign',(x,4.7,z),(5.8,2,.23),'wood','Wood',yaw(math.pi+a));text(f,heading,sub,kind='sign')
 for sx in [-2.4,2.4]:ball('Signs','RustyNail',(x+sx,4.7,z+.16),.1,'iron','Metal')

for i,a in enumerate([.2,1.0,2.1,2.9,3.8,4.6]):
 x,z=61*math.cos(a),53*math.sin(a)
 part('Lanterns','TrailLampPost',(x,3,z),(.3,5,.3),'bark','Wood',collide=True)
 lamp('Lanterns',(x,6,z),.75,actual=i%2==0)

# Sparse magical accents: luminous mushrooms and crystalline growths, not gameplay items.
for i,(x,z) in enumerate([(-44,17),(43,16),(-61,-32),(58,32),(-23,57),(27,-54)]):
 for j in range(3):
  px=x+j*.65;h=.5+j*.23
  part('MagicDetails','MushroomStem',(px,.4+h/2,z),(.14,h,.14),'cream','SmoothPlastic')
  ball('MagicDetails','LuminousMushroom',(px,.4+h,z),(.75,.25,.7),'mint' if i%2==0 else 'violet','Neon')
for x,z in [(-62,29),(62,-36),(-17,-59)]:
 for j in range(3):part('MagicDetails','BuriedCrystal',(x+j*.5,.85+j*.25,z),(.38,1+j*.3,.38),'violet','Neon',yaw(j*.4))

# Normalize all generated groups under the exterior model.
for n in nodes:n['g']='ForestExterior/'+n['g']
data={'nodes':nodes,'texts':texts,'lights':lights,'fog_anchors':[[-67,2.5,-35],[67,2.5,-34],[-60,2.5,49],[61,2.5,48]],'boundary_segments':boundary,'inner_tree_locations':tree_locations}
Path('work/forest/exterior.json').write_text(json.dumps(data,separators=(',',':'),ensure_ascii=False))
print('Exterior:',len(nodes),'parts,',len(lights),'lights,',52+len(tree_locations),'trees')
