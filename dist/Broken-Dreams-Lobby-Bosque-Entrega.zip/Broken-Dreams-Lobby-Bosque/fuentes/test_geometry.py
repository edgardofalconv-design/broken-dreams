import json,numpy as np,math
from pathlib import Path
s=json.load(open('work/forest/exterior.json'));nodes=s['nodes']
coll=[]
for n in nodes:
 R=np.array(n['r']).reshape(3,3)
 assert np.allclose(R.T@R,np.eye(3),atol=1e-5)
 assert np.linalg.det(R)>.999
 assert min(n['s'])>0
 if n['hit'] and n['n']!='ForestFoundation':coll.append(n)
# SAT overlap of an upright avatar box with each true oriented box (conservative for rocks).
def intersects(center,half,n):
 R=np.array(n['r']).reshape(3,3);P=np.array(n['p']);H=np.array(n['s'])/2;delta=P-center
 axes=list(np.eye(3))+[R[:,i] for i in range(3)]
 axes+=[np.cross(np.eye(3)[:,i],R[:,j]) for i in range(3) for j in range(3)]
 for axis in axes:
  if np.linalg.norm(axis)<1e-7:continue
  ra=np.dot(half,np.abs(axis));rb=np.dot(H,np.abs(R.T@axis))
  if abs(np.dot(delta,axis))>=ra+rb-.001:return False
 return True
probes=[]
for t in np.linspace(0,math.tau,240,endpoint=False):
 for offset in [-1.5,0,1.5]:probes.append(((55+offset)*math.cos(t),(47+offset)*math.sin(t),'loop'))
for z in np.linspace(27,64,75):
 for x in [-2.5,0,2.5]:probes.append((x,z,'entry'))
for x,z in [(-61,8),(61,7),(0,60)]:probes.append((x,z,'clearing'))
fail=[]
for x,z,route in probes:
 for n in coll:
  if abs(n['p'][0]-x)>max(n['s'])+4 or abs(n['p'][2]-z)>max(n['s'])+4:continue
  if intersects(np.array([x,3,z]),np.array([1.25,2.35,1.25]),n):fail.append((route,round(x,1),round(z,1),n['g'],n['n'],n['p']))
# Every radial boundary ray must encounter a visible collidable bank, with overlap between segments.
banks=[n for n in nodes if n['n']=='RootAndRockBank'];missing=[]
for a in np.linspace(0,math.tau,720,endpoint=False):
 p=np.array([83*math.cos(a),5,77*math.sin(a)])
 if not any(np.all(np.abs(np.array(n['r']).reshape(3,3).T@(p-np.array(n['p'])))<=np.array(n['s'])/2+.05) for n in banks):missing.append(a)
assert not missing,('Boundary gaps',missing[:5])
print('Boundary: 720 rays covered by visible solid forest banks')
if fail:
 print('PATH COLLISIONS:',json.dumps(list({(x[3],x[4],tuple(x[5])) for x in fail})));raise SystemExit(1)
assert len(banks)==56
report={'sampled_avatar_positions':len(probes),'path_collisions':0,'natural_boundary_rays':720,'boundary_gaps':0,'parts_added_geometry':len(nodes),'trees':75,'lights_added':len(s['lights']),'test_environment':'Offline analytic geometry, not Roblox Studio'}
Path('work/forest/geometry_validation.json').write_text(json.dumps(report,indent=2))
print('PASS:',report)
