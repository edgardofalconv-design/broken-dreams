local fs=require("@lune/fs")
local serde=require("@lune/serde")
local roblox=require("@lune/roblox")
local Instance,Vector3,Vector2,CFrame,Color3,UDim2,Enum=roblox.Instance,roblox.Vector3,roblox.Vector2,roblox.CFrame,roblox.Color3,roblox.UDim2,roblox.Enum
local NumberSequence,NumberSequenceKeypoint,NumberRange,ColorSequence=roblox.NumberSequence,roblox.NumberSequenceKeypoint,roblox.NumberRange,roblox.ColorSequence
local base=fs.readFile("work/delivery/descargas_verificadas/Broken-Dreams-Lobby.rbxlx")
local game=roblox.deserializePlace(base)
local workspace=game:GetService("Workspace")
local lobby=assert(workspace:FindFirstChild("BrokenDreamsLobby"),"Existing lobby missing")
assert(not lobby:FindFirstChild("ForestExterior"),"Exterior already exists")
local origin=lobby:GetAttribute("Origin")
local state=game:GetService("ReplicatedStorage").BrokenDreamsLobbyState
local before={};local baseCount=0
for _,o in lobby:GetDescendants() do
 if o:IsA("BasePart") then
  baseCount+=1;table.insert(before,{o,o.CFrame,o.Size,o.Color,o.CanCollide,o.Material,o.Transparency})
 end
end
assert(baseCount==3550)
local boundary=assert(lobby.TentStructure.Collision:FindFirstChild("EntrySafetyBoundary"),"Old entry blocker missing")
local removedName=boundary:GetFullName();boundary:Destroy()

local function new(class,name,parent)
 local o=Instance.new(class);o.Name=name;o.Parent=parent;return o
end
local function color(c)return Color3.fromRGB(c[1],c[2],c[3]) end
local function label(parent,name,value,pos,size)
 local o=new("TextLabel",name,parent);o.BackgroundTransparency=1;o.Position=pos;o.Size=size
 o.Text=value;o.TextColor3=Color3.fromRGB(243,207,144);o.Font=Enum.Font.Garamond;o.TextScaled=true;o.TextWrapped=true
 return o
end
local groups={}
local function group(path)
 if groups[path] then return groups[path] end
 local parent=lobby;local full=""
 for segment in path:gmatch("[^/]+") do
  full=full=="" and segment or full.."/"..segment
  if not groups[full] then groups[full]=new("Model",segment,parent) end
  parent=groups[full]
 end
 return parent
end
local data=serde.decode("json",fs.readFile("work/forest/exterior.json"))
local parts={}
for i,n in data.nodes do
 local o=new(n.shape=="Wedge" and "WedgePart" or "Part",n.n,group(n.g))
 o.Size=Vector3.new(unpack(n.s));o.CFrame=CFrame.new(origin+Vector3.new(unpack(n.p)))*CFrame.new(0,0,0,unpack(n.r))
 o.Anchored=true;o.Material=Enum.Material[n.m];o.Color=color(n.c);o.Transparency=n.t
 o.CanCollide=n.hit;o.CanQuery=n.hit;o.CanTouch=false;o.CastShadow=n.m~="Neon"
 o.TopSurface=Enum.SurfaceType.Smooth;o.BottomSurface=Enum.SurfaceType.Smooth
 if n.shape=="Ball" or n.shape=="Cylinder" then o.Shape=Enum.PartType[n.shape] end
 parts[i]=o
end
for _,t in data.texts do
 local gui=new("SurfaceGui","SignDisplay",parts[t.id+1]);gui.Face=Enum.NormalId.Front
 gui.SizingMode=Enum.SurfaceGuiSizingMode.FixedSize;gui.CanvasSize=Vector2.new(900,350)
 gui.LightInfluence=.3;gui.AlwaysOnTop=false;gui.MaxDistance=90
 if t.sub~="" then
  label(gui,"Heading",t.title,UDim2.fromScale(.04,.08),UDim2.fromScale(.92,.5))
  label(gui,"Detail",t.sub,UDim2.fromScale(.04,.63),UDim2.fromScale(.92,.25))
 else label(gui,"Heading",t.title,UDim2.fromScale(.04,.12),UDim2.fromScale(.92,.76)) end
end
for _,l in data.lights do
 local light=new("PointLight","WarmExteriorLight",parts[l.id+1]);light.Color=color(l.color)
 light.Range=l.range;light.Brightness=l.brightness;light.Shadows=false
end
for _,p in data.fog_anchors do
 local anchor=new("Part","GroundMistAnchor",group("ForestExterior/SoftMist"))
 anchor.Size=Vector3.new(1,1,1);anchor.Position=origin+Vector3.new(unpack(p));anchor.Transparency=1
 anchor.Anchored=true;anchor.CanCollide=false;anchor.CanQuery=false;anchor.CanTouch=false
 local emitter=new("ParticleEmitter","SoftGroundMist",anchor)
 emitter.Texture="rbxasset://textures/particles/smoke_main.dds"
 emitter.Rate=.3;emitter.Lifetime=NumberRange.new(7,10);emitter.Speed=NumberRange.new(.1,.3)
 emitter.SpreadAngle=Vector2.new(180,180);emitter.LightInfluence=.7;emitter.RotSpeed=NumberRange.new(-3,3)
 emitter.Size=NumberSequence.new({NumberSequenceKeypoint.new(0,10),NumberSequenceKeypoint.new(1,19)})
 emitter.Transparency=NumberSequence.new({NumberSequenceKeypoint.new(0,1),NumberSequenceKeypoint.new(.3,.94),NumberSequenceKeypoint.new(.7,.94),NumberSequenceKeypoint.new(1,1)})
 emitter.Color=ColorSequence.new(Color3.fromRGB(162,184,177))
end
local lighting=game:GetService("Lighting")
assert(not lighting:FindFirstChild("BD_ForestAtmosphere"))
local atmosphere=new("Atmosphere","BD_ForestAtmosphere",lighting)
atmosphere.Density=.2;atmosphere.Offset=.1;atmosphere.Color=Color3.fromRGB(166,188,186)
atmosphere.Decay=Color3.fromRGB(87,81,113);atmosphere.Haze=.9;atmosphere.Glare=.04

-- Extend only the area check; countdown logic and camera behavior stay intact.
local client=game:GetService("StarterGui").BrokenDreamsLobbyHUD.LobbyHUD
local old='local inside=p~=nil and math.abs(p.X)<38 and p.Z>-32 and p.Z<35 and p.Y>-3 and p.Y<34'
local replacement=[[local boundsMin=state:GetAttribute("LobbyBoundsMin") or Vector3.new(-38,-3,-32)
 local boundsMax=state:GetAttribute("LobbyBoundsMax") or Vector3.new(38,34,35)
 local inside=p~=nil and p.X>boundsMin.X and p.X<boundsMax.X and p.Y>boundsMin.Y and p.Y<boundsMax.Y and p.Z>boundsMin.Z and p.Z<boundsMax.Z]]
local start,stop=string.find(client.Source,old,1,true);assert(start,"Expected client area check not found")
client.Source=string.sub(client.Source,1,start-1)..replacement..string.sub(client.Source,stop+1)
state:SetAttribute("LobbyBoundsMin",Vector3.new(-94,-8,-88));state:SetAttribute("LobbyBoundsMax",Vector3.new(94,60,88))
lobby:SetAttribute("ExteriorVersion","1.1.0")
lobby.ForestExterior:SetAttribute("BaseCommit","8e3b94042fab518854c0976a617b0a7a0c3f2870")
lobby.ForestExterior:SetAttribute("Trees",75)
workspace.CurrentCamera.CFrame=CFrame.lookAt(origin+Vector3.new(29,24,67),origin+Vector3.new(0,12,27))
workspace.CurrentCamera.Focus=CFrame.new(origin+Vector3.new(0,12,27))
workspace.CurrentCamera.FieldOfView=75

-- Guard against accidental interior changes and runtime-source changes outside scope.
local preserved=0
for _,v in before do
 local o=v[1]
 if o~=boundary then
  assert(o:IsDescendantOf(lobby),"Original part removed unexpectedly")
  assert(o.CFrame==v[2] and o.Size==v[3] and o.Color==v[4] and o.CanCollide==v[5] and o.Material==v[6] and o.Transparency==v[7],o:GetFullName())
  preserved+=1
 end
end
assert(preserved==3549)
local original=roblox.deserializePlace(base)
for _,name in {"BrokenDreamsLobbyAPI","BrokenDreamsLobbyServer"} do
 assert(game:GetService("ServerScriptService")[name].Source==original:GetService("ServerScriptService")[name].Source)
end
local xml=roblox.serializePlace(game,true)
fs.writeFile("work/forest/Broken-Dreams-Lobby-Bosque.rbxlx",xml)
local reloaded=roblox.deserializePlace(xml)
local count=0
for _,o in reloaded:GetService("Workspace").BrokenDreamsLobby:GetDescendants() do if o:IsA("BasePart") then count+=1;assert(o.Anchored) end end
assert(count==3549+#data.nodes+#data.fog_anchors)
assert(reloaded:GetService("ReplicatedStorage").BrokenDreamsLobbyState:GetAttribute("LobbyBoundsMax")==Vector3.new(94,60,88))
assert(not reloaded:GetService("Workspace").BrokenDreamsLobby.TentStructure.Collision:FindFirstChild("EntrySafetyBoundary"))
fs.writeFile("work/forest/ForestExterior.rbxmx",roblox.serializeModel({lobby.ForestExterior},true))
fs.writeFile("work/forest/LobbyHUD.client.luau",client.Source)
fs.writeFile("work/forest/preservation.json",serde.encode("json",{originalParts=3550,preservedOriginalParts=preserved,removedOriginalPart=removedName,addedGeometryParts=#data.nodes,addedMistAnchors=#data.fog_anchors,totalParts=count,serverScriptsPreserved=true,robloxStudioTested=false},true))
print("PASS: preserved",preserved,"interior parts; added",#data.nodes,"exterior parts; total",count)
