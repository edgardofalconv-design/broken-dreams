local Players=game:GetService("Players")
local state=game:GetService("ReplicatedStorage"):WaitForChild("BrokenDreamsLobbyState")
local lobby=workspace:WaitForChild("BrokenDreamsLobby")
local portraits=state:WaitForChild("Portraits")
local function guiFor(model)
 local surface=model:FindFirstChild("DisplaySurface",true)
 return surface and surface:FindFirstChild("Display")
end
local malicia=guiFor(lobby.MaliciaBoard)
local map=guiFor(lobby.NextMapBoard)
local requestVersion=0
local function updateMalicia()
 requestVersion+=1;local thisRequest=requestVersion
 malicia.Detail.Text=state:GetAttribute("MaliciaName") or "POR DETERMINAR"
 malicia.Portrait.Image="";malicia.Placeholder.Visible=true
 local id=state:GetAttribute("MaliciaUserId") or 0
 if id>0 then
  task.spawn(function()
   local ok,image,ready=pcall(Players.GetUserThumbnailAsync,Players,id,Enum.ThumbnailType.AvatarBust,Enum.ThumbnailSize.Size420x420)
   if ok and ready and requestVersion==thisRequest then malicia.Portrait.Image=image;malicia.Placeholder.Visible=false end
  end)
 end
end
local function updateMap()
 map.Detail.Text=state:GetAttribute("NextMapName") or "MAPA PENDIENTE"
 map.Portrait.Image=state:GetAttribute("NextMapImage") or ""
 map.Placeholder.Visible=map.Portrait.Image==""
end
for _,key in ipairs({"MaliciaName","MaliciaUserId"}) do state:GetAttributeChangedSignal(key):Connect(updateMalicia) end
for _,key in ipairs({"NextMapName","NextMapImage"}) do state:GetAttributeChangedSignal(key):Connect(updateMap) end
updateMap();updateMalicia()
for _,model in ipairs(lobby.CharacterGallery:GetChildren()) do
 local display=guiFor(model)
 if display then
  local name=model:GetAttribute("CharacterName"):gsub(" ","_")
  local function refresh() display.Portrait.Image=portraits:GetAttribute(name) or "";display.Placeholder.Visible=display.Portrait.Image=="" end
  portraits:GetAttributeChangedSignal(name):Connect(refresh);refresh()
 end
end
local function joined(player)
 if state:GetAttribute("AssignLobbySpawn") then player.RespawnLocation=lobby.PlayerSpawns.LobbySpawn end
end
Players.PlayerAdded:Connect(joined)
for _,player in ipairs(Players:GetPlayers()) do joined(player) end
-- No bucle de cuenta atrás: el futuro RoundService llamará a API.SetCountdown.
