-- API exclusiva del servidor. No inicia partidas ni asigna asesino.
local state=game:GetService("ReplicatedStorage"):WaitForChild("BrokenDreamsLobbyState")
local API={}
local function imageId(value)
 assert(type(value)=="string" and (value=="" or value:match("^rbxassetid://%d+$")), "Usa rbxassetid://ID o una cadena vacía")
 return value
end
function API.SetCountdown(seconds)
 assert(type(seconds)=="number" and seconds==seconds and seconds<math.huge and (seconds==-1 or seconds>=0),"Tiempo inválido")
 state:SetAttribute("RemainingSeconds",seconds==-1 and -1 or math.floor(seconds))
end
function API.SetNextMap(name,asset)
 assert(type(name)=="string","Nombre inválido")
 local checked=imageId(asset)
 state:SetAttribute("NextMapImage",checked);state:SetAttribute("NextMapName",name)
end
function API.SetPortrait(characterName,asset)
 local portraits=state:FindFirstChild("Portraits")
 characterName=characterName:gsub(" ","_")
 assert(portraits:GetAttribute(characterName)~=nil,"Superviviente desconocido")
 portraits:SetAttribute(characterName,imageId(asset))
end
-- Mayor malicia obligatoria. Empate: menor UserId; nunca se usa azar.
-- Devuelve nil si faltan datos: nunca escoge arbitrariamente por defecto.
function API.GetHighestMalice(players,readMalice)
 assert(type(readMalice)=="function","Proporciona la función que lee tu malicia autoritativa")
 local best,bestValue=nil,-math.huge
 for _,player in ipairs(players) do
  local value=readMalice(player)
  if type(value)~="number" or value~=value or math.abs(value)==math.huge then
   return nil,"Malicia no disponible para "..player.Name
  end
  if value>bestValue or (value==bestValue and (not best or player.UserId<best.UserId)) then best=player;bestValue=value end
 end
 return best,bestValue
end
function API.RefreshMalicia(players,readMalice)
 local player,value=API.GetHighestMalice(players,readMalice)
 if not player then
  state:SetAttribute("MaliciaUserId",0);state:SetAttribute("MaliciaName","POR DETERMINAR");state:SetAttribute("MaliciaValue",0)
  return nil,value
 end
 state:SetAttribute("MaliciaValue",value);state:SetAttribute("MaliciaName",player.DisplayName);state:SetAttribute("MaliciaUserId",player.UserId)
 return player,value
end
return API
