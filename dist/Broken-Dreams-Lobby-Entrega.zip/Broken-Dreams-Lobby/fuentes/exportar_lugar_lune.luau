local fs=require("@lune/fs")
local serde=require("@lune/serde")
local roblox=require("@lune/roblox")
local Instance,Enum,Vector3,Vector2,CFrame,Color3,UDim,UDim2=roblox.Instance,roblox.Enum,roblox.Vector3,roblox.Vector2,roblox.CFrame,roblox.Color3,roblox.UDim,roblox.UDim2
local NumberRange,NumberSequence,NumberSequenceKeypoint,ColorSequence=roblox.NumberRange,roblox.NumberSequence,roblox.NumberSequenceKeypoint,roblox.ColorSequence
local game=Instance.new("DataModel")
local Workspace=game:GetService("Workspace")
local ReplicatedStorage=game:GetService("ReplicatedStorage")
local ServerScriptService=game:GetService("ServerScriptService")
local StarterGui=game:GetService("StarterGui")
local Lighting=game:GetService("Lighting")
Lighting.ClockTime=14
Workspace.CurrentCamera=Instance.new("Camera")
Workspace.CurrentCamera.Parent=Workspace
local ORIGIN=Vector3.new(0,8,0)
local APPLY_LIGHTING=true
local created={};local previousLighting={}
local function remember(o)table.insert(created,o);return o end
local history={FinishRecording=function()end};local recording="offline"
local function new(class,name,parent)
 local o=Instance.new(class);o.Name=name;o.Parent=parent;return o
end
local function color(c)return Color3.fromRGB(c[1],c[2],c[3]) end
local function label(parent,name,value,pos,size,textColor)
 local object=new("TextLabel",name,parent)
 object.BackgroundTransparency=1;object.Position=pos;object.Size=size
 object.Text=value;object.TextColor3=textColor;object.Font=Enum.Font.Garamond
 object.TextScaled=true;object.TextWrapped=true;object.BorderSizePixel=0
 return object
end
local SCENE=serde.decode("json",fs.readFile("work/lobby/scene.json"))
local API_SOURCE=fs.readFile("work/lobby/LobbyAPI.luau")
local SERVER_SOURCE=fs.readFile("work/lobby/LobbyServer.server.luau")
local CLIENT_SOURCE=fs.readFile("work/lobby/LobbyHUD.client.luau")
local function construct()
local ok,err=xpcall(function()
 local lobby=remember(new("Model","BrokenDreamsLobby",nil))
 lobby:SetAttribute("GeneratorVersion","1.0.0")
 lobby:SetAttribute("Origin",ORIGIN)
 lobby:SetAttribute("FootprintStuds","72 x 60")
 local folders={}
 local function group(path)
  if folders[path] then return folders[path] end
  local parent=lobby;local full=""
  for segment in string.gmatch(path,"[^/]+") do
   full=full=="" and segment or full.."/"..segment
   if not folders[full] then folders[full]=new("Model",segment,parent) end
   parent=folders[full]
  end
  return parent
 end
 local parts={}
 for i,n in ipairs(SCENE.nodes) do
  local class=n.shape=="Wedge" and "WedgePart" or n.shape=="Spawn" and "SpawnLocation" or "Part"
  local object=new(class,n.n,group(n.g))
  object.Anchored=true;object.Size=Vector3.new(unpack(n.s));object.Color=color(n.c)
  object.Material=Enum.Material[n.m];object.CanCollide=n.hit;object.CanTouch=false;object.CanQuery=n.hit
  object.Transparency=n.t;object.TopSurface=Enum.SurfaceType.Smooth;object.BottomSurface=Enum.SurfaceType.Smooth
  object.CastShadow=n.m~="Neon" and n.t<1
  object.CFrame=CFrame.new(ORIGIN+Vector3.new(unpack(n.p)))*CFrame.new(0,0,0,unpack(n.r))
  if n.shape=="Ball" or n.shape=="Cylinder" then object.Shape=Enum.PartType[n.shape] end
  if class=="SpawnLocation" then object.Neutral=true;object.Duration=0;object.AllowTeamChangeOnTouch=false;object.Enabled=true end
  parts[i]=object
 end
 for _,t in ipairs(SCENE.texts) do
  local surface=parts[t.id+1]
  local gui=new("SurfaceGui","Display",surface)
  gui.Face=Enum.NormalId.Front;gui.SizingMode=Enum.SurfaceGuiSizingMode.FixedSize
  gui.CanvasSize=t.kind=="portrait" and Vector2.new(400,650) or Vector2.new(1000,650)
  gui.LightInfluence=.15;gui.AlwaysOnTop=false;gui.MaxDistance=100;gui.ClipsDescendants=true
  local heading=label(gui,"Heading",t.title,UDim2.fromScale(.05,.035),UDim2.fromScale(.9,.17),color(t.color))
  if t.kind=="title" then heading.Position=UDim2.fromScale(.05,.05);heading.Size=UDim2.fromScale(.9,.9)
  else
   local portrait=new("ImageLabel","Portrait",gui);portrait.BackgroundTransparency=1
   portrait.Position=UDim2.fromScale(.08,.23);portrait.Size=UDim2.fromScale(.84,.59);portrait.Image="";portrait.ScaleType=Enum.ScaleType.Fit
   label(gui,"Placeholder",t.kind=="malicia" and "?" or "◇",UDim2.fromScale(.22,.28),UDim2.fromScale(.56,.43),color(t.color))
   label(gui,"Detail",t.kind=="malicia" and "POR DETERMINAR" or t.kind=="map" and "MAPA PENDIENTE" or "",UDim2.fromScale(.06,.84),UDim2.fromScale(.88,.11),color(t.color))
   if t.kind=="portrait" then
    heading.Position=UDim2.fromScale(.04,.81);heading.Size=UDim2.fromScale(.92,.15)
    portrait.Position=UDim2.fromScale(.06,.04);portrait.Size=UDim2.fromScale(.88,.72)
    surface.Parent:SetAttribute("CharacterName",t.title)
   end
  end
 end
 for _,l in ipairs(SCENE.lights) do
  local light=new("PointLight","WarmLight",parts[l.id+1]);light.Color=color(l.color)
  light.Range=l.range;light.Brightness=l.brightness;light.Shadows=l.shadows
 end
 for _,model in ipairs({lobby.MaliciaBoard,lobby.SkinCorner}) do
  local anchor=model:FindFirstChildWhichIsA("BasePart",true)
  local attachment=new("Attachment","MagicMotes",anchor)
  local particles=new("ParticleEmitter","SubtleMotes",attachment)
  particles.Texture="rbxasset://textures/particles/sparkles_main.dds"
  particles.Rate=1.5;particles.Lifetime=NumberRange.new(2,4);particles.Speed=NumberRange.new(.15,.5)
  particles.SpreadAngle=Vector2.new(180,180);particles.LightEmission=.7
  particles.Size=NumberSequence.new(.09);particles.Color=ColorSequence.new(Color3.fromRGB(204,139,255))
  particles.Transparency=NumberSequence.new({NumberSequenceKeypoint.new(0,1),NumberSequenceKeypoint.new(.2,.35),NumberSequenceKeypoint.new(1,1)})
 end
 local state=remember(new("Folder","BrokenDreamsLobbyState",nil))
 state:SetAttribute("Origin",ORIGIN);state:SetAttribute("RemainingSeconds",-1)
 state:SetAttribute("LobbyWaitSeconds",45) -- Valor de ejemplo editable; no inicia cuenta atrás.
 state:SetAttribute("AssignLobbySpawn",true)
 state:SetAttribute("NextMapName","MAPA PENDIENTE");state:SetAttribute("NextMapImage","")
 state:SetAttribute("MaliciaName","POR DETERMINAR");state:SetAttribute("MaliciaUserId",0);state:SetAttribute("MaliciaValue",0)
 local portraits=new("Folder","Portraits",state)
 for _,name in ipairs(SCENE.characters) do portraits:SetAttribute(name:gsub(" ","_"),"") end
 local hud=remember(new("ScreenGui","BrokenDreamsLobbyHUD",nil))
 hud.ResetOnSpawn=false;hud.IgnoreGuiInset=false;hud.DisplayOrder=10;hud.Enabled=true
 local panel=new("Frame","Panel",hud);panel.AnchorPoint=Vector2.new(.5,0);panel.Position=UDim2.new(.5,0,0,10);panel.Size=UDim2.new(.8,0,0,84)
 panel.BackgroundColor3=Color3.fromRGB(33,19,42);panel.BackgroundTransparency=.14;panel.BorderSizePixel=0
 local limit=new("UISizeConstraint","ResponsiveBounds",panel);limit.MaxSize=Vector2.new(360,84);limit.MinSize=Vector2.new(200,84)
 local corner=new("UICorner","Corners",panel);corner.CornerRadius=UDim.new(0,10)
 local stroke=new("UIStroke","GoldTrim",panel);stroke.Color=Color3.fromRGB(204,148,58);stroke.Thickness=1.5
 label(panel,"Heading","LA PARTIDA COMIENZA EN",UDim2.fromScale(.05,.12),UDim2.fromScale(.9,.26),Color3.fromRGB(245,208,141))
 label(panel,"Time","—:—",UDim2.fromScale(.05,.43),UDim2.fromScale(.9,.46),Color3.fromRGB(255,238,208))
 local client=new("LocalScript","LobbyHUD",hud);client.Source=CLIENT_SOURCE
 local api=remember(new("ModuleScript","BrokenDreamsLobbyAPI",nil));api.Source=API_SOURCE
 local server=remember(new("Script","BrokenDreamsLobbyServer",nil));server.Source=SERVER_SOURCE
 if APPLY_LIGHTING then
  local settings={Ambient=Color3.fromRGB(100,78,115),OutdoorAmbient=Color3.fromRGB(119,107,135),Brightness=2,ClockTime=17.3,GlobalShadows=true,ShadowSoftness=.6,ExposureCompensation=.2,EnvironmentDiffuseScale=.65,EnvironmentSpecularScale=.4}
  local backup=new("Folder","PreviousLighting",lobby)
  for key,value in pairs(settings) do previousLighting[key]=Lighting[key];backup:SetAttribute(key,Lighting[key]);Lighting[key]=value end
  local bloom=remember(new("BloomEffect","BD_SubtleBloom",Lighting));bloom.Intensity=.15;bloom.Size=20;bloom.Threshold=1.4
  local correction=remember(new("ColorCorrectionEffect","BD_WarmFantasy",Lighting));correction.Saturation=.06;correction.Contrast=.04;correction.TintColor=Color3.fromRGB(255,241,231)
  -- Existing effects are preserved. Current LightingStyle is left compatible with the project.
 end
 lobby.Parent=Workspace;state.Parent=ReplicatedStorage;hud.Parent=StarterGui;api.Parent=ServerScriptService;server.Parent=ServerScriptService

 if Workspace.CurrentCamera then Workspace.CurrentCamera.CFrame=CFrame.lookAt(ORIGIN+Vector3.new(0,10,28),ORIGIN+Vector3.new(0,8,-20)) end
 print(string.format("BROKEN DREAMS construido: %d piezas, %d luces, 72 × 60 studs. Ejecuta VERIFICAR_LOBBY y después Play.",#SCENE.nodes,#SCENE.lights))
end,function(e) return tostring(e)..debug.traceback() end)
if ok then history:FinishRecording(recording,Enum.FinishRecordingOperation.Commit)
else
 for i=#created,1,-1 do created[i]:Destroy() end
 for key,value in pairs(previousLighting) do Lighting[key]=value end
 history:FinishRecording(recording,Enum.FinishRecordingOperation.Cancel)
 error("Construcción cancelada y objetos nuevos retirados: "..tostring(err))
end

return Workspace:FindFirstChild("BrokenDreamsLobby")

end
local lobby=construct()
Lighting.TimeOfDay="17:18:00"
Workspace.CurrentCamera:Destroy()
local camera=new("Camera","Camera",Workspace)
camera.CFrame=CFrame.lookAt(ORIGIN+Vector3.new(0,10,28),ORIGIN+Vector3.new(0,8,-20))
camera.Focus=CFrame.new(ORIGIN+Vector3.new(0,8,-20));camera.FieldOfView=80
Workspace.CurrentCamera=camera
Workspace.Gravity=196.2
local starter=game:GetService("StarterPlayer")
starter.CameraMode=Enum.CameraMode.Classic;starter.CameraMinZoomDistance=6;starter.CameraMaxZoomDistance=24
local place=roblox.serializePlace(game,true)
fs.writeFile("work/delivery/Broken-Dreams-Lobby.rbxlx",place)
local reread=roblox.deserializePlace(place)
local loaded=reread:GetService("Workspace"):FindFirstChild("BrokenDreamsLobby")
assert(loaded,"Missing saved lobby")
local partCount=0
for _,obj in loaded:GetDescendants() do
 if obj:IsA("BasePart") then partCount+=1;assert(obj.Anchored) end
end
assert(partCount==#SCENE.nodes,"Geometry not preserved")
assert(reread:GetService("ServerScriptService").BrokenDreamsLobbyAPI.Source==API_SOURCE)
assert(reread:GetService("ServerScriptService").BrokenDreamsLobbyServer.Source==SERVER_SOURCE)
assert(reread:GetService("StarterGui").BrokenDreamsLobbyHUD.LobbyHUD.Source==CLIENT_SOURCE)
assert(reread:GetService("ReplicatedStorage").BrokenDreamsLobbyState:GetAttribute("RemainingSeconds")==-1)
assert(loaded:GetAttribute("Origin")==ORIGIN)
assert(loaded.PlayerSpawns.LobbySpawn:IsA("SpawnLocation"))
fs.writeFile("work/delivery/Broken-Dreams-Lobby.rbxmx",roblox.serializeModel({lobby},true))
print("PASS serialize/deserialize:",partCount,"BaseParts, scripts, attributes, spawn.")
print("Place bytes:",#place)
