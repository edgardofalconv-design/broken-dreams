import json, math, random
from pathlib import Path
import numpy as np

OUT=Path('/workspace/output'); OUT.mkdir(exist_ok=True)
WORK=Path('/workspace/work/lobby')
random.seed(481)
nodes=[]; texts=[]; lights=[]
I=np.eye(3)
def rgb(h): return [int(h[i:i+2],16) for i in (0,2,4)]
C={k:rgb(v) for k,v in dict(wood='65402C',plank='90603C',dark='2D202A',gold='CE943A',gold2='F3BF61',red='78293C',purple='492355',cream='AF9274',iron='37303D',violet='AD52E0',warm='FFD185',ink='251B35').items()}
def yaw(a):
 c,s=math.cos(a),math.sin(a);return np.array([[c,0,s],[0,1,0],[-s,0,c]])
def part(group,name,pos,size,col,mat='Wood',rot=None,shape='Block',collide=False,trans=0):
 n=dict(g=group,n=name,p=list(map(float,pos)),s=list(map(float,size)),c=C[col] if isinstance(col,str) else col,m=mat,r=(I if rot is None else rot).flatten().tolist(),shape=shape,hit=collide,t=trans)
 nodes.append(n); return len(nodes)-1
def ball(g,n,p,s,c,mat='SmoothPlastic'):return part(g,n,p,(s,s,s) if isinstance(s,(float,int)) else s,c,mat,shape='Ball')
def beam(g,n,a,b,width,c,mat='Wood',depth=None):
 a,b=np.array(a,dtype=float),np.array(b,dtype=float); v=b-a; length=np.linalg.norm(v)
 if length<0.001:return
 y=v/length; ref=np.array([0,0,1]) if abs(y[2])<.95 else np.array([1,0,0]); x=np.cross(y,ref);x/=np.linalg.norm(x);z=np.cross(x,y)
 return part(g,n,(a+b)/2,(width,length,depth or width),c,mat,np.column_stack((x,y,z)))
def path(g,n,pts,width,c,mat='Wood'):
 for a,b in zip(pts,pts[1:]):beam(g,n,a,b,width,c,mat)
def ring(g,n,center,r,width,c,plane='xz',count=32):
 pts=[]
 for t in np.linspace(0,math.tau,count+1):
  off=np.array([r*math.cos(t),0,r*math.sin(t)]) if plane=='xz' else np.array([r*math.cos(t),r*math.sin(t),0])
  pts.append(np.array(center)+off)
 path(g,n,pts,width,c,'Metal')
def triangle(g,name,a,b,c,color):
 # Two genuine WedgeParts per arbitrary triangle; matches Roblox's WedgePart solid.
 a,b,c=map(lambda v:np.array(v,dtype=float),(a,b,c))
 ab,ac,bc=b-a,c-a,c-b
 if np.dot(ab,ab)>max(np.dot(ac,ac),np.dot(bc,bc)): a,c=c,a
 elif np.dot(ac,ac)>np.dot(bc,bc):a,b=b,a
 ab,ac,bc=b-a,c-a,c-b
 right=np.cross(ac,ab); nr=np.linalg.norm(right)
 if nr<1e-6:return
 right/=nr; back=bc/np.linalg.norm(bc);up=np.cross(bc,right);up/=np.linalg.norm(up)
 h=abs(np.dot(ab,up))
 for mid,rot,depth in [((a+b)/2,np.column_stack((right,up,back)),abs(np.dot(ab,back))),((a+c)/2,np.column_stack((-right,up,-back)),abs(np.dot(ac,back)))]:
  if depth>.001:part(g,name,mid,(.06,h,depth),color,'Fabric',rot,'Wedge')
def cloth(g,name,rows,color,holes=False):
 for j in range(len(rows)-1):
  for k in range(len(rows[0])-1):
   if holes and random.random()<.035:continue
   a,b,c,d=rows[j][k],rows[j][k+1],rows[j+1][k],rows[j+1][k+1]
   triangle(g,name,a,b,c,color);triangle(g,name,b,d,c,color)
def text(partid,title,sub='',kind='label',color=None):
 texts.append(dict(id=partid,title=title,sub=sub,kind=kind,color=color or C['warm']))
def lamp(g,p,scale=1,actual=True,tint='warm'):
 x,y,z=p;s=scale
 part(g,'LanternBase',(x,y-.65*s,z),(1*s,.18*s,.8*s),'iron','Metal')
 part(g,'LanternCap',(x,y+.65*s,z),(1.1*s,.2*s,.9*s),'gold','Metal')
 i=part(g,'AmberGlass',(x,y,z),(.65*s,1.05*s,.5*s),tint,'Neon',trans=.12)
 for dx in [-.4,.4]:
  for dz in [-.3,.3]:beam(g,'LanternCage',(x+dx*s,y-.65*s,z+dz*s),(x+dx*s,y+.65*s,z+dz*s),.08*s,'iron','Metal')
 ring(g,'LanternHandle',(x,y+.95*s,z),.22*s,.06*s,'gold','xy',8)
 if actual:lights.append(dict(id=i,color=C[tint],brightness=1.4,range=15*s,shadows=False))
def crate(p,s=2.2):
 x,y,z=p;g='Decorations/Crates';part(g,'CrateCore',(x,y+s/2,z),(s,s,s),'wood',collide=True)
 for h in [.16,s-.16]:part(g,'CrateRim',(x,y+h,z),(s+.12,.22,s+.12),'plank')
 for dz in [-s/2-.03,s/2+.03]:
  for dx in [-s/2+.18,s/2-.18]:part(g,'CrateBrace',(x+dx,y+s/2,z+dz),(.25,s,.15),'gold')
  beam(g,'DiagonalBrace',(x-s/2+.2,y+.3,z+dz),(x+s/2-.2,y+s-.3,z+dz),.2,'plank')
def barrel(p):
 x,y,z=p;g='Decorations/Barrels'
 for j in range(12):
  a=j*math.tau/12;part(g,'Stave',(x+1.05*math.cos(a),y+1.55,z+1.05*math.sin(a)),(.53,3.1,.22),'plank',rot=yaw(-a+math.pi/2))
 part(g,'BarrelCollider',(x,y+1.55,z),(1.9,3.1,1.9),'wood',collide=True)
 for h in [.35,1.6,2.8]:ring(g,'Hoop',(x,y+h,z),1.14,.16,'iron',count=12)
def board(g,center,w,h,title,kind,angle=0):
 center=np.array(center);R=yaw(angle)
 def P(v):return center+R@np.array(v)
 def bp(n,p,s,c,mat='Wood',shape='Block',hit=False):return part(g,n,P(p),s,c,mat,R,shape,hit)
 bp('Backing',(0,0,0),(w+.7,h+.6,.65),'wood',hit=True)
 face=part(g,'DisplaySurface',P((0,0,.36)),(w-.45,h-.5,.12),'ink' if kind!='map' else rgb('173944'),'SmoothPlastic',R@yaw(math.pi))
 text(face,title,kind=kind)
 for x in [-w/2,w/2]:
  bp('GoldOuterFrame',(x,0,.52),(.42,h+.8,.5),'gold','Metal')
  bp('GoldInnerFrame',(x-math.copysign(.32,x),0,.65),(.11,h,.16),'gold2','Metal')
 for y in [-h/2,h/2]:
  bp('GoldOuterFrame',(0,y,.52),(w+.8,.43,.5),'gold','Metal')
  bp('GoldInnerFrame',(0,y-math.copysign(.3,y),.65),(w,.11,.16),'gold2','Metal')
 # Raised curling ornaments, not a flat image border.
 for sx in [-1,1]:
  for sy in [-1,1]:
   pts=[]
   for t in np.linspace(0,math.tau*1.15,10):
    rad=(.9 if w>8 else .4)*(1-t/(math.tau*1.5));pts.append(P((sx*(w/2-.35+rad*math.cos(t)),sy*(h/2+.2+rad*math.sin(t)),.75)))
   path(g,'CarvedScroll',pts,.19 if w>8 else .12,'gold2','Metal')
 for dx in [-.85,0,.85]:
  bp('CrownPetal',(dx*(1 if w>8 else .5),h/2+.6,.35),(.5,1.3 if dx==0 else .8,.35),'gold','Metal','Ball')
 for x in [-w*.36,w*.36]:
  beam(g,'EaselLeg',P((x,-h/2-1.7,1.1)),P((x,h*.2,-.65)),.45,'wood')
 return face

# Floor and collision shell: 72 x 60 studs, floor walking level y=0.5.
part('WoodenFloor','Foundation',(0,-.1,0),(72,1,60),'wood',collide=True)
for row in range(30):
 z=-29+row*2
 cuts=[-36]+sorted([-24+random.uniform(-3,3),-12+random.uniform(-3,3),random.uniform(-3,3),12+random.uniform(-3,3),24+random.uniform(-3,3)])+[36]
 for a,b in zip(cuts,cuts[1:]):
  c=[max(0,min(255,v+random.randint(-14,14))) for v in C['plank']]
  part('WoodenFloor','WornPlank',((a+b)/2,.46,z),(b-a-.055,.12,1.94),c)
  if random.random()<.22:part('WoodenFloor','GrainScratch',((a+b)/2,.525,z+.3),(min(2,b-a-.2),.012,.025),'wood')
for z in [-30,30]:
 for x,w in [(0,72)] if z<0 else [(-21,30),(21,30)]:
  part('TentStructure/Collision','Wall',(x,8,z),(w,16,.5),'wood',collide=True,trans=1)
for x in [-36,36]:part('TentStructure/Collision','Wall',(x,8,0),(.5,16,60),'wood',collide=True,trans=1)
part('TentStructure/Collision','EntrySafetyBoundary',(0,7,33),(12,14,.4),'wood',collide=True,trans=1)
part('PlayerSpawns','EntryDeck',(0,.15,31),(12,.7,6),'wood',collide=True)
part('PlayerSpawns','EntryRunner',(0,.53,28),(8,.06,10),'purple','Fabric')
for x in [-4,4]:part('PlayerSpawns','RunnerGoldEdge',(x,.57,28),(.13,.02,10),'gold','Fabric')

# Poles, beams, fabric side walls with pleats and genuinely broken hem.
perimeter=[(-35,-29),(-23,-29),(-11.5,-29),(0,-29),(11.5,-29),(23,-29),(35,-29),(35,-10),(35,10),(35,29),(6,29),(-6,29),(-35,29),(-35,10),(-35,-10)]
for x,z in perimeter:
 part('TentStructure/Timber','Post',(x,9.5,z),(.65,19,.65),'wood',collide=True)
 for h in [1.1,17.4,18.8]:part('TentStructure/Timber','PostCollar',(x,h,z),(.85,.2,.85),'gold','Metal')
 ball('TentStructure/Timber','Finial',(x,19.2,z),.85,'gold')
edges=list(zip(perimeter,perimeter[1:]+perimeter[:1]))
for idx,(a,b) in enumerate(edges):
 if a==(6,29) and b==(-6,29):continue
 a,b=np.array([a[0],0,a[1]]),np.array([b[0],0,b[1]])
 beam('TentStructure/Timber','TopRail',a+[0,18.5,0],b+[0,18.5,0],.48,'wood')
 rows=[]; normal=np.cross((b-a)/np.linalg.norm(b-a),[0,1,0])
 for h in range(3):
  row=[]
  for k in range(7):
   t=k/6; p=a+(b-a)*t+normal*(.35*math.sin(k*2.1));p[1]=.8+h*8.55
   if h==0:p[1]+=random.uniform(0,1.2)
   row.append(p)
  rows.append(row)
 cloth('TentStructure/WallCloth','AgedCanvas',rows,'cream' if idx%3==0 else 'red',True)
 # Curved purple/red valance with taper toward hanging center.
 rows=[]
 for h in [0,1]:
  row=[]
  for k in range(7):
   t=k/6;p=a+(b-a)*t-normal*.6;p[1]=18.5-2.1*math.sin(math.pi*t)-h*(.35+1.5*math.sin(math.pi*t));row.append(p)
  rows.append(row)
 cloth('TentStructure/Swags','VelvetSwag',rows,'purple' if idx%2==0 else 'red')
 pts=[]
 for k in range(7):
  t=k/6;p=a+(b-a)*t-normal*.8;p[1]=18.3-1.2*math.sin(math.pi*t);pts.append(p)
 path('LightingProps/FairyStrings','Wire',pts,.055,'gold')
 for p in pts[1::2]:ball('LightingProps/FairyStrings','WarmBulb',p,.15,'warm','Neon')
 # Cloth patch with cross-stitch seams.
 p=a+(b-a)*.45-normal*.5;p[1]=6.8
 patchR=np.column_stack(((b-a)/np.linalg.norm(b-a),[0,1,0],normal))
 part('TentStructure/WallCloth','SewnPatch',p,(1.5,1.9,.08),'purple','Fabric',patchR)
 for dy in [-.7,0,.7]:beam('TentStructure/WallCloth','Stitch',p+patchR@np.array([-.8,dy,.09]),p+patchR@np.array([-.55,dy+.25,.09]),.055,'cream','Fabric')

# Real roof; removable only for editor inspection / external cutaway renders.
roofgroup='TentStructure/Roof'
outline=[(-35,-29),(-17.5,-29),(0,-29),(17.5,-29),(35,-29),(35,0),(35,29),(17.5,29),(0,29),(-17.5,29),(-35,29),(-35,0)]
for idx in range(len(outline)):
 a=np.array([outline[idx][0],18.7,outline[idx][1]]);b=np.array([outline[(idx+1)%len(outline)][0],18.7,outline[(idx+1)%len(outline)][1]])
 rows=[]
 for j in range(5):
  t=.055+.945*j/4;row=[]
  for k in range(4):
   v=k/3;edge=a*(1-v)+b*v;p=np.array([0,29,0])*(1-t)+edge*t;p[1]-=1.0*math.sin(math.pi*t)*math.sin(math.pi*v);row.append(p)
  rows.append(row)
 cloth(roofgroup,'RoofPanel',rows,['red','purple','cream'][idx%3],False)
 beam(roofgroup,'RoofRope',(0,28.9,0),a,.12,'gold')
ring(roofgroup,'CrownOpening',(0,29,0),1.8,.3,'gold',count=16)

# Center rug with spiral made of real thin 3D strips; nothing collidable in the central circle.
Rx=np.array([[0,-1,0],[1,0,0],[0,0,1]])
part('Carpet','CircularVelvet',(0,.57,1),( .09,24,24),'red','Fabric',Rx,'Cylinder')
ring('Carpet','GoldBorder',(0,.635,1),11.55,.20,'gold',count=64)
pts=[]
for t in np.linspace(0,math.pi*4.4,96):
 r=.15+t*.47;pts.append([r*math.cos(t),.65,1+r*math.sin(t)])
path('Carpet','GoldenDreamSpiral',pts,.62,'gold','Fabric')
for i in range(12):
 t=i*math.tau/12
 for d in [-.18,.18]:
  a=np.array([10.7*math.cos(t),.65,1+10.7*math.sin(t)]);b=np.array([9.6*math.cos(t+d),.65,1+9.6*math.sin(t+d)])
  beam('Carpet','WovenLeaf',a,b,.16,'gold','Fabric')

# Rear boards, accurate left-right assignment as seen from entrance.
for x,g,title,kind,ang in [(-21,'MaliciaBoard','MALICIA','malicia',.12),(21,'NextMapBoard','PRÓXIMO MAPA','map',-.12)]:
 part(g,'BoardPlatform',(x,.8,-22),(18,.6,6.5),'plank',collide=True)
 for dz,y in [(-18.8,.65),(-18.1,.57)]:part(g,'PlatformStep',(x,y,dz),(12,.25,.7),'plank',collide=True)
 board(g,(x,8.3,-23),15.5,10.5,title,kind,ang)
 for dx in [-8.5,8.5]:
  part('LightingProps','CandlePedestal',(x+dx,2,-20.7),(.8,3,.8),'wood')
  lamp('LightingProps',(x+dx,4.3,-20.7),.85)
 if kind=='malicia':
  ball(g,'SkullCrest',(x,15.0,-22.45),(1.8,1.7,.65),'gold2')
  for dx in [-.4,.4]:ball(g,'SkullEye',(x+dx,15.1,-22.08),(.37,.45,.15),'ink')
  for dx in [-.4,0,.4]:part(g,'SkullTooth',(x+dx,14.15,-22.3),(.23,.45,.35),'gold2')
  for side in [-1,1]:
   pts=[(x+side*(8.5+.5*math.sin(i)),.7+i*1.15,-23+.8*math.sin(i*.8)) for i in range(12)]
   path('Decorations/Corruption','TwistedRoot',pts,.22,'ink')
   path('Decorations/Corruption','VioletVein',[np.array(p)+[0,0,.15] for p in pts],.065,'violet','Neon')
  i=ball(g,'CorruptionGlow',(x,2,-21),.22,'violet','Neon');lights.append(dict(id=i,color=rgb('DE3B8A'),brightness=1.2,range=13,shadows=False))

# Six frames in a shallow, readable arc on the left, facing the center/front.
characters=['Rayman','Globox','Grand Minimus','Barbara','Murfy','Ly']
for i,name in enumerate(characters):
 x=-32+i*3.15;z=10-4.7*math.sin(math.pi*i/5);a=.42-.84*i/5
 board('CharacterGallery/'+name.replace(' ','_'),(x,4.7,z),3.25,5.6,name,'portrait',a)
for i in range(7):
 x=-34+i*3.3;z=9-4.5*math.sin(math.pi*i/6)
 part('CharacterGallery/Canopy','GalleryPole',(x,4.9,z-.8),(.18,8.8,.18),'gold')
 ball('CharacterGallery/Canopy','Finial',(x,9.4,z-.8),.32,'gold2')
 if i<6:
  nx=-34+(i+1)*3.3;nz=9-4.5*math.sin(math.pi*(i+1)/6)
  rows=[[[x,9.2,z-1],[nx,9.2,nz-1]],[[x,8.2,z+1.2],[nx,8.2,nz+1.2]]]
  cloth('CharacterGallery/Canopy','PurpleAwning',rows,'purple')
  lamp('LightingProps',(x+1.4,8.6,z+.8),.42,actual=(i==2))

# Skins nook, without a shop interaction yet.
part('SkinCorner','SmallRug',(26,.58,12),(.07,11,11),'purple','Fabric',Rx,'Cylinder')
ring('SkinCorner','RugBorder',(26,.63,12),5.1,.18,'gold',count=32)
for x,z in [(21,6),(33,6),(21,19),(33,19)]:
 part('SkinCorner/Canopy','Pole',(x,6,z),(.24,11,.24),'wood')
 ball('SkinCorner/Canopy','Finial',(x,11.7,z),.45,'gold')
cloth('SkinCorner/Canopy','PurpleCanopy',[[[21,11.3,6],[27,13,6],[33,11.3,6]],[[21,10.2,12],[27,12,12],[33,10.2,12]],[[21,11.3,19],[27,13,19],[33,11.3,19]]],'purple')
cloth('SkinCorner/Canopy','SideCurtain',[[[33,1,6],[33,1,12],[33,1,19]],[[32.6,6,6],[32.2,6,12],[32.6,6,19]],[[33,11.3,6],[33,10.2,12],[33,11.3,19]]],'purple')
for x,z in [(27,7),(30,17)]:
 part('SkinCorner','TableTop',(x,3,z),(5,.4,2.5),'plank',collide=True)
 for dx in [-2,2]:
  for dz in [-.8,.8]:part('SkinCorner','TableLeg',(x+dx,1.75,z+dz),(.27,2.5,.27),'wood')
 for j in range(3):
  part('SkinCorner','AncientBook',(x-.9,3.35+j*.23,z),(1.6,.19,1.05),['red','purple','cream'][j],rot=yaw(j*.14))
  part('SkinCorner','BookSpine',(x-.9,3.35+j*.23,z+.52),(1.6,.1,.07),'gold')
 for j in range(3):
  px=x+.7+j*.37;py=3.75+j*.24
  part('SkinCorner','MagicCrystal',(px,py,z),(.35,.9+j*.3,.35),'violet','Glass',yaw(.4*j),trans=.15)
  ball('SkinCorner','CrystalTip',(px,py+.5+j*.15,z),(.28,.4,.28),'violet','Neon')
 lamp('LightingProps',(x+1.7,4.0,z),.55,True)

# Chandelier, lamps, hanging chains, entry banners, clutter off circulation routes.
ring('LightingProps/Chandelier','IronRing',(0,18,-2),6,.32,'iron',count=24)
ring('LightingProps/Chandelier','GoldTrim',(0,18.2,-2),6,.12,'gold',count=24)
for i in range(6):
 a=i*math.tau/6;x,z=6*math.cos(a),-2+6*math.sin(a)
 beam('LightingProps/Chandelier','Suspension',(0,25,-2),(x,18.2,z),.095,'gold','Metal')
 beam('LightingProps/Chandelier','DropChain',(x,18,z),(x,16.5,z),.08,'iron','Metal')
 lamp('LightingProps/Chandelier',(x,15.5,z),1,actual=(i in [1,4]))
beam('LightingProps/Chandelier','MainChain',(0,25,-2),(0,28.9,-2),.15,'iron','Metal')
for x in [-7,7]:
 part('PlayerSpawns','EntryPillar',(x,2.2,27),(.8,3.4,.8),'wood',collide=True);lamp('LightingProps',(x,4.8,27),1.05)
for x in [-11,11]:
 part('Decorations/Banners','BannerPole',(x,4.5,27),(.18,8,.18),'gold')
 part('Decorations/Banners','HangingBanner',(x,5.3,27),(2.4,4.7,.08),'purple','Fabric')
 ring('Decorations/Banners','GoldSigil',(x,5.6,27.06),.65,.08,'gold','xy',14)
for p in [(-32,.53,-23),(-32,.53,-19),(32,.53,-20),(-33,.53,23),(-31,.53,25),(32,.53,25)]:crate(p,random.choice([1.8,2.2,2.5]))
for p in [(-32,.53,-25),(32,.53,-25),(-33,.53,20)]:barrel(p)
for x in [-33,33]:
 for z in [-9,16]:lamp('LightingProps',(x,12,z),1,False)
 # Floor roots remain outside the central movement area.
 for k in range(2):path('Decorations/Corruption','FloorRoot',[(x,.7,20-k),(x*.95,1,19-k),(x*.91,.7,17-k)],.15,'ink')

# Rear banner, without the forbidden play portal/button.
banner=part('Decorations','TitleBanner',(0,12.6,-28.2),(10,5,.12),'purple','Fabric',yaw(math.pi))
text(banner,'BROKEN\nDREAMS','',kind='title')
spawn=part('PlayerSpawns','LobbySpawn',(0,.58,27),(7,.12,4),'purple','Fabric',shape='Spawn',trans=1)
nodes[spawn]['hit']=False

# Flatten the woven ornament in world Y: beam width must not turn embroidery into a raised rail.
for n in nodes:
 if n['g']=='Carpet' and n['n']!='CircularVelvet':
  vertical=int(np.argmax(np.abs(np.array(n['r']).reshape(3,3)[1])))
  n['s'][vertical]=.025
data=dict(nodes=nodes,texts=texts,lights=lights,characters=characters)
WORK.joinpath('scene.json').write_text(json.dumps(data,separators=(',',':'),ensure_ascii=False))
print('Geometry:',len(nodes),'parts;',len(lights),'lights;',len(texts),'display surfaces')
