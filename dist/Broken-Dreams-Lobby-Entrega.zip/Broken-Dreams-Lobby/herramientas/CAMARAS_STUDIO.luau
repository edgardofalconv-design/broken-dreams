-- En modo Edit. Cambia VIEW por superior / entrada / cuadros / galeria / restaurar.
-- superior utiliza LocalTransparencyModifier: oculta techo solo en este editor.
local VIEW="superior"
assert(not game:GetService("RunService"):IsRunning(),"Usa estas cámaras en modo Edit")
local lobby=assert(workspace:FindFirstChild("BrokenDreamsLobby"),"Falta el lobby")
local origin=lobby:GetAttribute("Origin")
local camera=workspace.CurrentCamera
local views={superior={Vector3.new(0,70,78),Vector3.new(0,0,0),50},entrada={Vector3.new(0,8,28),Vector3.new(0,8,-20),80},cuadros={Vector3.new(0,12,7),Vector3.new(0,8,-23),75},galeria={Vector3.new(-24,9,25),Vector3.new(-24,5,7),65}}
local old=lobby:FindFirstChild("EditorCameraBackup")
if not old then
 old=Instance.new("Folder");old.Name="EditorCameraBackup";old:SetAttribute("CFrame",camera.CFrame);old:SetAttribute("FieldOfView",camera.FieldOfView);old.Parent=lobby
end
for _,object in ipairs(lobby:GetDescendants()) do
 if object:IsA("BasePart") then
  if object:GetAttribute("BD_PreviousLTM")~=nil then object.LocalTransparencyModifier=object:GetAttribute("BD_PreviousLTM");object:SetAttribute("BD_PreviousLTM",nil) end
  local roof=object:IsDescendantOf(lobby.TentStructure.Roof)
  local front=object:IsDescendantOf(lobby.TentStructure.WallCloth) and object.Position.Z-origin.Z>25
  if VIEW=="superior" and (roof or front) then object:SetAttribute("BD_PreviousLTM",object.LocalTransparencyModifier);object.LocalTransparencyModifier=1 end
 end
end
if VIEW=="restaurar" then camera.CFrame=old:GetAttribute("CFrame");camera.FieldOfView=old:GetAttribute("FieldOfView");old:Destroy()
else
 local view=assert(views[VIEW],"Vista no válida");camera.CFrame=CFrame.lookAt(origin+view[1],origin+view[2]);camera.FieldOfView=view[3]
end
print("Vista: "..VIEW..". Usa restaurar antes de guardar o probar Play.")
