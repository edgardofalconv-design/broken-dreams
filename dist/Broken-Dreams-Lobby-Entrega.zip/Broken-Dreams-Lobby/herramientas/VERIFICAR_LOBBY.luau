-- Ejecutar en Command Bar después del constructor. También sirve durante Play (Server).
local lobby=workspace:FindFirstChild("BrokenDreamsLobby")
assert(lobby,"Falta BrokenDreamsLobby")
local origin=lobby:GetAttribute("Origin")
local errors={};local checks=0
local function check(condition,message)
 checks+=1;if not condition then table.insert(errors,message);warn("FALLO: "..message) end
end
for _,name in ipairs({"TentStructure","WoodenFloor","Carpet","Decorations","LightingProps","MaliciaBoard","NextMapBoard","CharacterGallery","SkinCorner","PlayerSpawns"}) do check(lobby:FindFirstChild(name)~=nil,"Falta "..name) end
local partCount,lightCount=0,0
for _,object in ipairs(lobby:GetDescendants()) do
 if object:IsA("BasePart") then partCount+=1;check(object.Anchored,"Pieza sin anclar: "..object:GetFullName()) end
 if object:IsA("PointLight") then lightCount+=1 end
 if object:IsA("GuiButton") or object:IsA("ProximityPrompt") then check(false,"Interacción no prevista: "..object:GetFullName()) end
 if object:IsA("TextLabel") then check(not object.Text:upper():find("JUGAR",1,true),"Texto JUGAR inesperado") end
end
for _,pair in ipairs({{lobby.MaliciaBoard,-1},{lobby.NextMapBoard,1}}) do
 local surface=pair[1]:FindFirstChild("DisplaySurface",true)
 check(surface~=nil,"Falta superficie del cuadro")
 if surface then
  local p=surface.Position-origin
  check(p.X*pair[2]>10 and p.Z< -15,"Cuadro fuera de su esquina: "..pair[1].Name)
  check(surface.CFrame.LookVector.Z>.8,"Superficie mira hacia fuera: "..pair[1].Name)
  check(surface.Display.Face==Enum.NormalId.Front,"Cara de interfaz incorrecta")
 end
end
local portraits=0
for _,model in ipairs(lobby.CharacterGallery:GetChildren()) do
 if model:GetAttribute("CharacterName") then portraits+=1;check(model:FindFirstChild("DisplaySurface",true)~=nil,"Retrato sin superficie") end
end
check(portraits==6,"La galería debe tener seis espacios")
local hud=game:GetService("StarterGui"):FindFirstChild("BrokenDreamsLobbyHUD")
check(hud and hud:FindFirstChild("Panel")~=nil,"Falta HUD")
if hud then for _,o in ipairs(hud:GetDescendants()) do check(not o:IsA("GuiButton"),"No debe haber botones en HUD") end end
local state=game:GetService("ReplicatedStorage"):FindFirstChild("BrokenDreamsLobbyState")
check(state~=nil,"Falta estado replicado")
check(lobby.PlayerSpawns.LobbySpawn:IsA("SpawnLocation"),"Falta SpawnLocation")
local ray=RaycastParams.new();ray.FilterType=Enum.RaycastFilterType.Include;ray.FilterDescendantsInstances={lobby};ray.RespectCanCollide=true
local overlap=OverlapParams.new();overlap.FilterType=Enum.RaycastFilterType.Include;overlap.FilterDescendantsInstances={lobby};overlap.RespectCanCollide=true
-- Volumen de avatar 2.6 x 4.8 x 2.6 studs; rutas centrales y acceso a cuadros.
local probes={Vector3.new(0,0,27),Vector3.new(0,0,20),Vector3.new(0,0,12),Vector3.new(0,0,1),Vector3.new(0,0,-10),Vector3.new(0,0,-16),Vector3.new(-13,0,0),Vector3.new(13,0,0),Vector3.new(-21,0,-15),Vector3.new(21,0,-15)}
for _,point in ipairs(probes) do
 local hit=workspace:Raycast(origin+point+Vector3.new(0,6,0),Vector3.new(0,-8,0),ray)
 check(hit~=nil,"Sin suelo bajo "..tostring(point))
 if hit then
  check(math.abs(hit.Position.Y-(origin.Y+.4))<.5,"Suelo inesperado bajo "..tostring(point))
  local blocked=workspace:GetPartBoundsInBox(CFrame.new(hit.Position+Vector3.new(0,2.6,0)),Vector3.new(2.6,4.8,2.6),overlap)
  check(#blocked==0,"Paso bloqueado en "..tostring(point))
 end
end
print(string.format("BROKEN DREAMS: %d comprobaciones; %d errores; %d piezas; %d luces.",checks,#errors,partCount,lightCount))
if #errors==0 then print("Validación estructural correcta. Falta probar WASD, salto, cámara, móvil y multijugador en Play.") end
assert(#errors==0,table.concat(errors,"\n"))
