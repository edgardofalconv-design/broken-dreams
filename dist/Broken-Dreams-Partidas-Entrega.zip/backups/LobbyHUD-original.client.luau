local Players=game:GetService("Players")
local RunService=game:GetService("RunService")
local player=Players.LocalPlayer
local state=game:GetService("ReplicatedStorage"):WaitForChild("BrokenDreamsLobbyState")
local gui=script.Parent
local timer=gui.Panel.Time
local oldCamera=nil
local function update()
 local seconds=state:GetAttribute("RemainingSeconds") or -1
 timer.Text=seconds<0 and "—:—" or string.format("%02d:%02d",math.floor(seconds/60),seconds%60)
end
state:GetAttributeChangedSignal("RemainingSeconds"):Connect(update);update()
local elapsed=0
RunService.Heartbeat:Connect(function(dt)
 elapsed+=dt;if elapsed<.25 then return end;elapsed=0
 local root=player.Character and player.Character:FindFirstChild("HumanoidRootPart")
 local origin=state:GetAttribute("Origin")
 local p=root and origin and root.Position-origin
 local boundsMin=state:GetAttribute("LobbyBoundsMin") or Vector3.new(-38,-3,-32)
 local boundsMax=state:GetAttribute("LobbyBoundsMax") or Vector3.new(38,34,35)
 local inside=p~=nil and p.X>boundsMin.X and p.X<boundsMax.X and p.Y>boundsMin.Y and p.Y<boundsMax.Y and p.Z>boundsMin.Z and p.Z<boundsMax.Z
 gui.Enabled=inside
 if inside and not oldCamera then
  oldCamera={player.CameraMode,player.CameraMinZoomDistance,player.CameraMaxZoomDistance}
  player.CameraMode=Enum.CameraMode.Classic
  player.CameraMinZoomDistance=6;player.CameraMaxZoomDistance=24
 elseif not inside and oldCamera then
  player.CameraMode=oldCamera[1]
  -- Reset min first so restoring a smaller maximum never clamps incorrectly.
  player.CameraMinZoomDistance=0.5;player.CameraMaxZoomDistance=oldCamera[3];player.CameraMinZoomDistance=oldCamera[2]
  oldCamera=nil
 end
end)
